import 'package:flutter/material.dart';

void main() => runApp(const ProfileApp());

/// Plain data shown on the card.
/// Edit [defaultProfile] below to display your own (or fictional) details.
class Profile {
  const Profile({
    required this.name,
    required this.role,
    required this.email,
    required this.phone,
    required this.city,
  });

  final String name;
  final String role;
  final String email;
  final String phone;
  final String city;

  /// First letters of the first two words of [name], e.g. "Meera Nair" -> "MN".
  /// Falls back to "?" when the name is empty.
  String get initials {
    final words = name.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty);
    final letters = words.take(2).map((w) => w.substring(0, 1).toUpperCase()).join();
    return letters.isEmpty ? '?' : letters;
  }
}

const defaultProfile = Profile(
  name: 'Meera Nair',
  role: 'Flutter Intern',
  email: 'meera.nair@example.com',
  phone: '+91 90000 00000',
  city: 'Kochi, India',
);

/// Root widget: theme + a Scaffold whose body keeps the card centred,
/// at most 360 px wide, and scrollable so it never overflows on small screens.
class ProfileApp extends StatelessWidget {
  const ProfileApp({super.key, this.profile = defaultProfile});

  final Profile profile;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Profile Card',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(title: const Text('My Profile')),
        body: LayoutBuilder(
          builder: (context, viewport) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                // Fill the visible area so the card is vertically centred...
                constraints: BoxConstraints(minHeight: viewport.maxHeight),
                child: Center(
                  child: ConstrainedBox(
                    // ...but never wider than 360 px on large screens.
                    constraints: const BoxConstraints(maxWidth: 360),
                    child: ProfileCard(profile: profile),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// The card: a coloured header (avatar, name, role) above the contact rows.
class ProfileCard extends StatelessWidget {
  const ProfileCard({super.key, required this.profile});

  final Profile profile;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Card(
      margin: const EdgeInsets.all(16),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [scheme.primary, scheme.secondary],
              ),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: scheme.onPrimary,
                  child: Text(
                    profile.initials,
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: scheme.primary,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  profile.name,
                  textAlign: TextAlign.center,
                  style: textTheme.headlineSmall?.copyWith(
                    color: scheme.onPrimary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  profile.role,
                  textAlign: TextAlign.center,
                  style: textTheme.titleMedium?.copyWith(color: scheme.onPrimary),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            child: Column(
              children: [
                ContactRow(icon: Icons.email_outlined, text: profile.email),
                ContactRow(icon: Icons.phone_outlined, text: profile.phone),
                ContactRow(icon: Icons.location_on_outlined, text: profile.city),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// One reusable contact line: a round icon badge followed by text.
/// The text sits in an [Expanded] so long values wrap instead of overflowing.
class ContactRow extends StatelessWidget {
  const ContactRow({super.key, required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: scheme.primaryContainer,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 20, color: scheme.onPrimaryContainer),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(text, style: Theme.of(context).textTheme.bodyLarge),
          ),
        ],
      ),
    );
  }
}
