import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:profile_card_app/main.dart';

/// Pumps the full app on a simulated screen of [size] logical pixels.
Future<void> pumpApp(WidgetTester tester, {Size size = const Size(390, 844)}) async {
  tester.view.physicalSize = size * 3;
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(const ProfileApp());
}

void main() {
  group('Profile.initials', () {
    test('uses the first letters of the first two words', () {
      expect(const Profile(name: 'Meera Nair', role: '', email: '', phone: '', city: '').initials, 'MN');
      expect(const Profile(name: '  ada   b  c ', role: '', email: '', phone: '', city: '').initials, 'AB');
    });

    test('handles one word and empty names', () {
      expect(const Profile(name: 'Madonna', role: '', email: '', phone: '', city: '').initials, 'M');
      expect(const Profile(name: '   ', role: '', email: '', phone: '', city: '').initials, '?');
    });
  });

  group('ProfileCard content (checklist: avatar, name, role, 3 contact rows)', () {
    testWidgets('shows avatar initials, name and role', (tester) async {
      await pumpApp(tester);

      expect(find.byType(CircleAvatar), findsOneWidget);
      expect(find.text('MN'), findsOneWidget);
      expect(find.text('Meera Nair'), findsOneWidget);
      expect(find.text('Flutter Intern'), findsOneWidget);
    });

    testWidgets('shows exactly three contact rows with icons and text', (tester) async {
      await pumpApp(tester);

      expect(find.byType(ContactRow), findsNWidgets(3));
      expect(find.byIcon(Icons.email_outlined), findsOneWidget);
      expect(find.byIcon(Icons.phone_outlined), findsOneWidget);
      expect(find.byIcon(Icons.location_on_outlined), findsOneWidget);
      expect(find.text('meera.nair@example.com'), findsOneWidget);
      expect(find.text('+91 90000 00000'), findsOneWidget);
      expect(find.text('Kochi, India'), findsOneWidget);
    });

    testWidgets('ContactRow is reusable on its own', (tester) async {
      await tester.pumpWidget(const MaterialApp(
        home: Scaffold(body: ContactRow(icon: Icons.star, text: 'Hello')),
      ));

      expect(find.byIcon(Icons.star), findsOneWidget);
      expect(find.text('Hello'), findsOneWidget);
    });

    testWidgets('renders a custom Profile passed to the app', (tester) async {
      await tester.pumpWidget(const ProfileApp(
        profile: Profile(
          name: 'Ada Lovelace',
          role: 'Mathematician',
          email: 'ada@example.com',
          phone: '+44 0000 000000',
          city: 'London',
        ),
      ));

      expect(find.text('AL'), findsOneWidget);
      expect(find.text('Ada Lovelace'), findsOneWidget);
      expect(find.text('London'), findsOneWidget);
    });
  });

  group('Layout (checklist: centred, max width, narrow phone layout)', () {
    testWidgets('card is centred and capped at 360 px on a wide screen', (tester) async {
      await pumpApp(tester, size: const Size(1200, 800));

      final card = find.byType(ProfileCard);
      expect(tester.getSize(card).width, lessThanOrEqualTo(360));
      expect(tester.getCenter(card).dx, closeTo(600, 0.5));
    });

    testWidgets('fits a narrow 320 px phone without overflow', (tester) async {
      await pumpApp(tester, size: const Size(320, 568));

      expect(tester.takeException(), isNull);
      final card = find.byType(ProfileCard);
      expect(tester.getTopLeft(card).dx, greaterThanOrEqualTo(0));
      expect(tester.getTopRight(card).dx, lessThanOrEqualTo(320));
    });

    testWidgets('scrolls instead of overflowing on a very short screen', (tester) async {
      await pumpApp(tester, size: const Size(320, 300));

      expect(tester.takeException(), isNull);
      expect(find.byType(SingleChildScrollView), findsOneWidget);
    });
  });
}
